using System;
using Mdc;

namespace Mdc.Testes
{
    [TestClass]
    public class ProgramTests
    {
        [TestMethod]
        public void TestCalcularMDC_DoisNumeros()
        {
            
            Program programa = new Program();
            int num1 = 48;
            int num2 = 18;
            int esperado = 6;

            
            int resultado = programa.CalcularMDC(num1, num2);

            
            Assert.AreEqual(esperado, resultado);
        }

        [TestMethod]
        public void TestCalcularMDC_TresNumeros()
        {
            
            Program programa = new Program();
            int num1 = 36;
            int num2 = 24;
            int num3 = 12;
            int esperado = 12;

            
            int resultado = programa.CalcularMDC(num1, num2, num3);

            
            Assert.AreEqual(esperado, resultado);
        }
    }
}
