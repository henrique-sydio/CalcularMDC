﻿using System;

public class ProgramTests
{
    public static void Main(string[] args)
    {
        TestCalcularMDC_DoisNumeros();
        TestCalcularMDC_TresNumeros();
    }

    public static void TestCalcularMDC_DoisNumeros()
    {
        // Arrange
        Program programa = new Program();
        int num1 = 48;
        int num2 = 18;
        int esperado = 6;

        // Act
        int resultado = programa.CalcularMDC(num1, num2);

        // Assert
        if (resultado == esperado)
        {
            Console.WriteLine("TestCalcularMDC_DoisNumeros - Passou");
        }
        else
        {
            Console.WriteLine("TestCalcularMDC_DoisNumeros - Falhou. Resultado: " + resultado + ", Esperado: " + esperado);
        }
    }

    public static void TestCalcularMDC_TresNumeros()
    {
        // Arrange
        Program programa = new Program();
        int num1 = 36;
        int num2 = 24;
        int num3 = 12;
        int esperado = 12;

        // Act
        int resultado = programa.CalcularMDC(num1, num2, num3);

        // Assert
        if (resultado == esperado)
        {
            Console.WriteLine("TestCalcularMDC_TresNumeros - Passou");
        }
        else
        {
            Console.WriteLine("TestCalcularMDC_TresNumeros - Falhou. Resultado: " + resultado + ", Esperado: " + esperado);
        }
    }
}
