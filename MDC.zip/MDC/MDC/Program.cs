﻿using System;

namespace Mdc;

public class Program
{
    public int CalcularMDC(int a, int b)
    {
        while (b != 0)
        {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }

    public int CalcularMDC(int a, int b, int c)
    {
        return CalcularMDC(CalcularMDC(a, b), c);
    }

    static void Main(string[] args)
    {
        Program programa = new Program();

        Console.WriteLine("\r\n█▀▄▀█ █▀▄ █▀▀   █▀▀ ▄▀█ █░░ █▀▀ █░█ █░░ ▄▀█ ▀█▀ █ █▀█ █▄░█\r\n█░▀░█ █▄▀ █▄▄   █▄▄ █▀█ █▄▄ █▄▄ █▄█ █▄▄ █▀█ ░█░ █ █▄█ █░▀█");
        Console.WriteLine("\nEscolha o número de valores para calcular o MDC:");
        Console.WriteLine("\n1 - Dois valores");
        Console.WriteLine("\n2 - Três valores");
        Console.WriteLine("\n3 - Sair");
        Console.Write("\nDigite uma opção: ");
        int opcao = int.Parse(Console.ReadLine());

        if (opcao == 1)
        {
            Console.Write("Digite o primeiro número: ");
            int num1 = int.Parse(Console.ReadLine());

            Console.Write("Digite o segundo número: ");
            int num2 = int.Parse(Console.ReadLine());

            int mdc = programa.CalcularMDC(num1, num2);
            Console.WriteLine("O MDC de " + num1 + " e " + num2 + " é: " + mdc);
        }
        else if (opcao == 2)
        {
            Console.Write("Digite o primeiro número: ");
            int num1 = int.Parse(Console.ReadLine());

            Console.Write("Digite o segundo número: ");
            int num2 = int.Parse(Console.ReadLine());

            Console.Write("Digite o terceiro número: ");
            int num3 = int.Parse(Console.ReadLine());

            int mdc = programa.CalcularMDC(num1, num2, num3);
            Console.WriteLine("O MDC de " + num1 + ", " + num2 + " e " + num3 + " é: " + mdc);
        }
        else if (opcao == 3)
        {
            Console.WriteLine("Programa encerrado.");
        }
        else
        {
            Console.WriteLine("Opção inválida.");
        }
    }
}
